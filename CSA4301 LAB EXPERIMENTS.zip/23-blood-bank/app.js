const BG=['A+','A-','B+','B-','O+','O-','AB+','AB-'];
const stock=r=>CL('stock').filter(s=>s.user===r.user).map(s=>`${esc(s.group)}: ${s.units}`).join(' · ')||'-';
runPortal({title:'🩸 Blood Management',users:[{name:'Demo Donor',email:'donor@blood.com',password:'1234',role:'user',phone:'9876500004'},{name:'City Blood Bank',email:'bank@blood.com',password:'1234',role:'hospital',phone:'0452 2345678'}],
 regRoles:['user','hospital'],regExtra:regExtraPhone,hint:'Demo: donor@blood.com / 1234 · bank@blood.com / 1234',
 seed:{donors:[{user:'donor@blood.com',name:'Ramesh K',group:'O+',age:28,city:'Madurai',phone:'9876500004'},{user:'x@blood.com',name:'Sneha R',group:'B+',age:25,city:'Chennai',phone:'9876500010'}],banks:[{user:'bank@blood.com',name:'City Blood Bank',city:'Madurai',address:'GH Road',phone:'0452 2345678'}],stock:[{user:'bank@blood.com',group:'O+',units:12},{user:'bank@blood.com',group:'A+',units:8},{user:'bank@blood.com',group:'B-',units:2}]},
 tabs:{user:[
  {t:'Post Donor Info',k:'donors',own:1,fields:[{n:'name',l:'Donor name'},{n:'group',l:'Blood group',t:'select',o:BG},{n:'age',l:'Age',t:'number'},{n:'city',l:'City'},{n:'phone',l:'Phone'}],cols:[['Name','name'],['Group','group'],['Age','age'],['City','city'],['Phone','phone']],del:1},
  {t:'My Donor Info',k:'donors',own:1,cols:[['Name','name'],['Group','group'],['City','city'],['Phone','phone']],edit:0,del:1},
  {t:'Search Donor',k:'donors',filters:[{n:'group',l:'Any group',o:BG},{n:'city',l:'City'}],cols:[['Name','name'],['Group','group'],['Age','age'],['City','city'],['Phone','phone']]},
  {t:'Search Blood Bank',k:'banks',filters:[{n:'city',l:'City'}],cols:[['Blood bank','name'],['City','city'],['Address','address'],['Phone','phone'],['Stock (units)',stock]]}],
 hospital:[
  {t:'Post Blood Bank Info',k:'banks',own:1,fields:[{n:'name',l:'Blood bank name'},{n:'city',l:'City'},{n:'address',l:'Address'},{n:'phone',l:'Phone'}],cols:[['Name','name'],['City','city'],['Address','address'],['Phone','phone']],edit:1,del:1},
  {t:'Update Blood Group Status',k:'stock',own:1,fields:[{n:'group',l:'Blood group',t:'select',o:BG},{n:'units',l:'Units available',t:'number'}],cols:[['Group','group'],['Units','units'],['Updated','date']],edit:1,del:1},
  {t:'View Blood Banks',k:'banks',cols:[['Blood bank','name'],['City','city'],['Phone','phone'],['Stock (units)',stock]]}]}});
