# 23. Blood Management Information System

Features: donor registration, blood bank stock updates and donor and blood bank search.

## Run
Open `index.html` in a browser. No server or install needed.

## Demo logins
donor@blood.com / 1234 | bank@blood.com / 1234

## Notes
- Front-end only: data is saved in the browser (localStorage). Clear site data to reset.
- Payments, OTP, email and SMS are simulated (demo only).
