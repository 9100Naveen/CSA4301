# 36. EduConnect Online Teaching Platform

Features: a course catalog, study materials, quizzes, assignments, a discussion forum and a teacher dashboard.

## Run
Open `index.html` in a browser. No server or install needed.

## Demo logins
student@edu.com / 1234 | teacher@edu.com / 1234 | admin@edu.com / admin123

## Notes
- Front-end only: data is saved in the browser (localStorage). Clear site data to reset.
- Payments, OTP, email and SMS are simulated (demo only).
