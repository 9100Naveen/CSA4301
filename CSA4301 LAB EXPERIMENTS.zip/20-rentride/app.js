const TYPES=['Car','SUV','Truck','Bike'],vfields=[{n:'name',l:'Vehicle name'},{n:'type',l:'Type',t:'select',o:TYPES},{n:'price',l:'Price per day (₹)',t:'number'},{n:'loc',l:'Location'},{n:'img',l:'Icon (emoji)',r:false}];
runPortal({title:'🚗 RentRide',users:[{name:'Rent Admin',email:'admin@rent.com',password:'admin123',role:'admin'},{name:'Demo Customer',email:'user@rent.com',password:'1234',role:'user',phone:'9876500003',address:'12 Lake Road, Madurai'}],
 regRoles:['user'],regExtra:regExtraPhone,hint:'Demo: admin@rent.com / admin123 · user@rent.com / 1234',
 seed:{vehicles:[{name:'Swift Dzire',type:'Car',price:1800,loc:'Madurai',img:'🚗'},{name:'Innova Crysta',type:'SUV',price:3500,loc:'Madurai',img:'🚙'},{name:'Tata Ace',type:'Truck',price:2500,loc:'Coimbatore',img:'🚚'},{name:'Royal Enfield',type:'Bike',price:900,loc:'Chennai',img:'🏍'}],bookings:[],reviews:[{user:'user@rent.com',vname:'Swift Dzire',rating:5,text:'Clean car, smooth pickup.'}]},
 tabs:{admin:[
  {t:'Add Vehicle',k:'vehicles',fields:vfields,cols:[['Vehicle',r=>(r.img||'')+' '+esc(r.name)],['Type','type'],RS('Price/day','price'),['Location','loc']],edit:1,del:1},
  {t:'Manage Bookings',k:'bookings',cols:[W('Customer'),['Vehicle','vname'],['Start','start'],['Days','days'],RS('Total','total'),['Phone','phone'],['Status','status']],status:{o:['Pending','Approved','Rejected','Cancelled','Completed']}},
  {t:'Reviews',k:'reviews',cols:[W('Customer'),['Vehicle','vname'],['Rating',r=>'★'.repeat(r.rating)],['Review','text']]},
  {t:'My Profile',type:'profile',fields:['phone']}],
 user:[
  {t:'Search Vehicle',k:'vehicles',filters:[{n:'type',l:'Any type',o:TYPES},{n:'loc',l:'Location'},{l:'Max price/day',fn:(r,v)=>r.price<=+v}],cols:[['Vehicle',r=>(r.img||'')+' '+esc(r.name)],['Type','type'],RS('Price/day','price'),['Location','loc']],
   act:{l:'Book',k:'bookings',ask:[{n:'start',l:'Start date (YYYY-MM-DD)',def:()=>addDays(today(),1)},{n:'days',l:'Number of days',def:1}],def:{status:'Pending'},mk:(r,a,me)=>({vid:r.id,vname:r.name,start:a.start,days:+a.days,total:r.price*a.days,phone:me.phone||'',address:me.address||''}),ok:'Booking request sent'}},
  {t:'My Bookings',k:'bookings',own:1,cols:[['Vehicle','vname'],['Start','start'],['Days','days'],RS('Total','total'),['Status','status']],acts:[{l:'Cancel',patch:{status:'Cancelled'},show:r=>r.status==='Pending'}]},
  {t:'Reviews',k:'reviews',fields:[{n:'vname',l:'Vehicle',t:'select',o:()=>CL('vehicles').map(v=>v.name)},{n:'rating',l:'Rating (1-5)',t:'number'},{n:'text',l:'Your review'}],cols:[W('User'),['Vehicle','vname'],['Rating',r=>'★'.repeat(r.rating)],['Review','text']]},
  {t:'My Profile',type:'profile',fields:['phone','address']}]}});
