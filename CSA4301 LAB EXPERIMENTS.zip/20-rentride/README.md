# 20. RentRide (Vehicle Rental)

Features: vehicle search, booking, admin approval, reviews and profile management.

## Run
Open `index.html` in a browser. No server or install needed.

## Demo logins
user@rent.com / 1234 | admin@rent.com / admin123

## Notes
- Front-end only: data is saved in the browser (localStorage). Clear site data to reset.
- Payments, OTP, email and SMS are simulated (demo only).
