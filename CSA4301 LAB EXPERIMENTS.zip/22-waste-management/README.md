# 22. Smart Waste Management

Features: garbage bin management, best-route assignment for drivers, public complaints and reports.

## Run
Open `index.html` in a browser. No server or install needed.

## Demo logins
public@waste.com / 1234 | driver@waste.com / 1234 | admin@waste.com / admin123

## Notes
- Front-end only: data is saved in the browser (localStorage). Clear site data to reset.
- Payments, OTP, email and SMS are simulated (demo only).
