const binCols=[['Bin','name'],['Area','area'],['Fill level',r=>`<b class="${+r.fill>=70?'bad':'ok'}">${r.fill}%</b>`]];
const mapLink=r=>`<a href="${esc(r.url||'#')}" target="_blank">Open in Google Maps</a>`;
runPortal({title:'♻ Smart Waste Management',users:[{name:'Waste Admin',email:'admin@waste.com',password:'admin123',role:'admin'},{name:'Driver Mani',email:'driver@waste.com',password:'1234',role:'driver'},{name:'Demo Citizen',email:'public@waste.com',password:'1234',role:'public'}],
 regRoles:['public'],hint:'Demo: admin@waste.com / admin123 · driver@waste.com / 1234 · public@waste.com / 1234',
 seed:{bins:[{name:'Bin A – Bus stand',area:'Anna Nagar',fill:85},{name:'Bin B – Market',area:'Anna Nagar',fill:40},{name:'Bin C – School',area:'KK Nagar',fill:72},{name:'Bin D – Park',area:'KK Nagar',fill:20}],complaints:[{user:'public@waste.com',area:'Anna Nagar',description:'Garbage not collected for 3 days',status:'Open'}],routes:[]},
 tabs:{admin:[
  {t:'Garbage Bins',k:'bins',fields:[{n:'name',l:'Bin name / location'},{n:'area',l:'Area'},{n:'fill',l:'Fill level %',t:'number'}],cols:binCols,edit:1,del:1},
  {t:'Drivers',type:'users',role:'driver',del:1,add:[{n:'name',l:'Driver name'},{n:'email',l:'Login email',t:'email'},{n:'password',l:'Password'}]},
  {t:'Assign Route',type:'custom',fn:m=>{const best=CL('bins').filter(b=>+b.fill>=60).sort((a,b)=>b.fill-a.fill),ds=Auth.users().filter(u=>u.role==='driver');
   m.innerHTML=`<div class="card"><h3>Best route (bins ≥ 60% full, fullest first)</h3><ol>${best.map(b=>`<li>${esc(b.name)} – ${b.fill}%</li>`).join('')||'<li>No bins need collection</li>'}</ol><form id="f" class="row"><select name="d">${ds.map(u=>`<option value="${u.email}">${esc(u.name)}</option>`).join('')}</select><input type="date" name="date" value="${today()}"><button class="btn">Assign route to driver</button></form></div><div class="card">${tbl(['Driver','Date','Stops','Map'],CL('routes').map(r=>[esc(UN(r.driver)),r.date,esc(r.stops.join(' → ')),mapLink(r)]))}</div>`;
   $('#f').onsubmit=e=>{const f=fd(e);SC('routes',[...CL('routes'),{id:uid(),driver:f.d,date:f.date,stops:best.map(b=>b.name),url:'https://www.google.com/maps/dir/'+best.map(b=>encodeURIComponent(b.name+' '+b.area)).join('/')}]);toast('Route assigned');refresh()}}},
  {t:'Garbage Report',type:'report',items:[{l:'Total bins',k:'bins'},{l:'Bins ≥ 70% full',k:'bins',where:r=>+r.fill>=70},{l:'Average fill %',fn:()=>Math.round(CL('bins').reduce((s,b)=>s+ +b.fill,0)/(CL('bins').length||1))}],groups:[{l:'Bins by area',k:'bins',by:'area'}]},
  {t:'Complaints',k:'complaints',cols:[W('Citizen'),['Area','area'],['Complaint','description'],['Photo','img'],['Status','status']],status:{o:['Open','In progress','Resolved']}}],
 public:[
  {t:'Register Complaint',k:'complaints',own:1,def:{status:'Open'},fields:[{n:'area',l:'Area'},{n:'description',l:'Complaint',t:'textarea'},{n:'img',l:'Photo (optional)',t:'file'}],cols:[['Date','date'],['Area','area'],['Complaint','description'],['Status','status']]},
  {t:'My Complaints',k:'complaints',own:1,cols:[['Date','date'],['Area','area'],['Complaint','description'],['Status','status']]}],
 driver:[
  {t:'Daily Work',k:'routes',where:(r,me)=>r.driver===me.email,cols:[['Date','date'],['Stops',r=>esc(r.stops.join(' → '))],['Map',mapLink]]},
  {t:'Best Route',type:'custom',fn:m=>{const r=CL('routes').filter(x=>x.driver===ME().email).pop();m.innerHTML=`<div class="card"><h3>Today's best route</h3>${r?`<ol>${r.stops.map(s=>`<li>${esc(s)}</li>`).join('')}</ol><a class="btn" target="_blank" href="${esc(r.url)}">Navigate in Google Maps</a>`:'<p>No route assigned yet.</p>'}</div>`}},
  {t:'Update Garbage Load',k:'bins',cols:binCols,acts:[{l:'Update load',ask:[{n:'fill',l:'New fill level % (0-100)'}]}]}]}});
