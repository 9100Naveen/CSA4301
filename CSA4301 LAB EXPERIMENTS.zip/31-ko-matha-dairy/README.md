# 31. Ko-Matha Dairy Farm

Features: product ordering, stock entry, daily, monthly and yearly reports, vendor and cow records.

## Run
Open `index.html` in a browser. No server or install needed.

## Demo logins
cust@dairy.com / 1234 | admin@dairy.com / admin123 (log in via the "Login / Register" tab)

## Notes
- Front-end only: data is saved in the browser (localStorage). Clear site data to reset.
- Payments, OTP, email and SMS are simulated (demo only).
