const PRODS=()=>CL('products').map(p=>p.name);
const sums=(rows,len,f)=>Object.entries(rows.reduce((a,r)=>{const k=r.date.slice(0,len);a[k]=(a[k]||0)+f(r);return a},{})).sort().reverse();
runPortal({title:'🐄 Ko-Matha Dairy Farm',users:[{name:'Farm Admin',email:'admin@dairy.com',password:'admin123',role:'admin'},{name:'Demo Customer',email:'cust@dairy.com',password:'1234',role:'customer'}],
 regRoles:['customer','admin'],hint:'Demo: admin@dairy.com / admin123 · cust@dairy.com / 1234',
 seed:{products:[{name:'A1 Milk (1 L)',price:60},{name:'Curd (500 g)',price:35},{name:'Cova-sweet (250 g)',price:120},{name:'Butter (500 g)',price:280},{name:'Ghee (500 ml)',price:450}],
  stock:[{product:'A1 Milk (1 L)',qty:120},{product:'Ghee (500 ml)',qty:30}],orders:[{user:'cust@dairy.com',product:'A1 Milk (1 L)',qty:4,amount:240,status:'Delivered'}],
  vendors:[{name:'Murugan Dairy',phone:'9876500011',litres:80,rate:42},{name:'Lakshmi Farms',phone:'9876500012',litres:55,rate:44}],cows:[{tag:'GIR-01',breed:'Gir (A1)',age:5,yield:12,health:'Healthy'},{tag:'SAH-07',breed:'Sahiwal (A1)',age:4,yield:10,health:'Vaccinated'}],contact:[]},
 pub:{Home:{type:'html',html:'<h2>Pure A1 milk from Indian cows</h2><p>Fresh milk, curd, cova-sweet, butter and ghee delivered from our smart dairy farm.</p>'},
  'About Us':{type:'html',html:'<h3>About us</h3><p>Ko-Matha Dairy Farm works with Indian A1 cow holders and uses sensors and records to keep every litre traceable.</p>'},
  Farm:{type:'html',html:'<h3>Our farm</h3><ul><li>Indigenous Gir and Sahiwal cows</li><li>Hygienic automated milking</li><li>A1 milk is rich in beneficial proteins and easy to digest</li></ul>'},
  Products:{k:'products',cols:[['Product','name'],RS('Price','price')]},
  'Contact Us':{k:'contact',noTable:1,form:'Contact us',btn:'Send',ok:'Message sent',fields:[{n:'name',l:'Name'},{n:'phone',l:'Phone'},{n:'msg',l:'Message',t:'textarea'}],cols:[]}},
 tabs:{admin:[
  {t:'Stock Entry',k:'stock',fields:[{n:'product',l:'Product',t:'select',o:PRODS},{n:'qty',l:'Quantity added',t:'number'}],cols:[['Date','date'],['Product','product'],['Quantity','qty']],del:1},
  {t:'Reports',type:'custom',fn:m=>{m.innerHTML=`<div class="card"><h3>Stock and sales reports</h3><select id="p"><option value="10">Daily report</option><option value="7">Monthly report</option><option value="4">Yearly report</option></select><div id="o"></div></div>`;
   const d=()=>{const L=+$('#p').value,st=sums(CL('stock'),L,r=>+r.qty),od=CL('orders').map(o=>({...o,date:o.date})),sl=sums(od,L,r=>+r.amount),sq=sums(od,L,r=>+r.qty);
    $('#o').innerHTML=tbl(['Period','Stock added (units)','Units sold','Sales amount'],[...new Set([...st,...sl].map(x=>x[0]))].sort().reverse().map(k=>[k,(st.find(x=>x[0]===k)||[0,0])[1],(sq.find(x=>x[0]===k)||[0,0])[1],rs((sl.find(x=>x[0]===k)||[0,0])[1])]))};$('#p').onchange=d;d()}},
  {t:'Customer Purchases',k:'orders',cols:[['Date','date'],W('Customer'),['Product','product'],['Qty','qty'],RS('Amount','amount'),['Status','status']],status:{o:['Placed','Packed','Delivered']}},
  {t:'Milk Vendors',k:'vendors',fields:[{n:'name',l:'Vendor name'},{n:'phone',l:'Phone'},{n:'litres',l:'Litres per day',t:'number'},{n:'rate',l:'Rate per litre',t:'number'}],cols:[['Vendor','name'],['Phone','phone'],['Litres/day','litres'],RS('Rate','rate')],edit:1,del:1},
  {t:'Cow Details',k:'cows',fields:[{n:'tag',l:'Cow tag'},{n:'breed',l:'Breed'},{n:'age',l:'Age (years)',t:'number'},{n:'yield',l:'Milk litres/day',t:'number'},{n:'health',l:'Health status'}],cols:[['Tag','tag'],['Breed','breed'],['Age','age'],['Litres/day','yield'],['Health','health']],edit:1,del:1}],
 customer:[
  {t:'Products',k:'products',cols:[['Product','name'],RS('Price','price')],act:{l:'Order online',k:'orders',def:{status:'Placed'},ask:[{n:'qty',l:'Quantity',def:1}],mk:(r,a)=>({product:r.name,qty:+a.qty,amount:r.price*a.qty}),ok:'Order placed'}},
  {t:'My Orders',k:'orders',own:1,cols:[['Date','date'],['Product','product'],['Qty','qty'],RS('Amount','amount'),['Status','status']]}]}});
