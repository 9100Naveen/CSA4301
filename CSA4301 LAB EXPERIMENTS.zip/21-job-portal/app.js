const CATS=['IT','Teaching','Healthcare','Sales','Engineering','Other'];
runPortal({title:'💼 JobConnect',users:[{name:'Portal Admin',email:'admin@job.com',password:'admin123',role:'admin'},{name:'TechNova HR',email:'dir@job.com',password:'1234',role:'director',approved:true,company:'TechNova'},{name:'Demo Applicant',email:'app@job.com',password:'1234',role:'user',approved:true}],
 regRoles:['user','director'],hint:'Demo: admin@job.com / admin123 · dir@job.com / 1234 · app@job.com / 1234. New directors wait for admin approval.',
 gate:me=>me.role==='director'&&!me.approved?'Approval pending: the admin has not approved your director login yet.':'',
 seed:{vacancies:[{user:'dir@job.com',title:'Junior Web Developer',company:'TechNova',location:'Madurai',category:'IT',salary:'₹3.6 LPA',description:'HTML, CSS, JavaScript.',contact:'hr@technova.example',img:''},{user:'dir@job.com',title:'Maths Teacher',company:'TechNova Academy',location:'Chennai',category:'Teaching',salary:'₹3 LPA',description:'B.Ed preferred.',contact:'hr@technova.example',img:''}],applications:[]},
 tabs:{admin:[
  {t:'Approve Director',type:'users',role:'director',cols:[['Name','name'],['Company','company'],['Email','email'],['Approved',r=>r.approved?'Yes':'Pending']],toggle:{key:'approved'}},
  {t:'View Users',type:'users',role:'user',del:1},
  {t:'View Report',type:'report',items:[{l:'Vacancies',k:'vacancies'},{l:'Applications',k:'applications'},{l:'Job seekers',fn:()=>Auth.users().filter(u=>u.role==='user').length}],groups:[{l:'Vacancies by category',k:'vacancies',by:'category'},{l:'Applications per vacancy',k:'applications',by:'title'}]}],
 director:[
  {t:'Post Vacancy',k:'vacancies',own:1,fields:[{n:'title',l:'Job title'},{n:'company',l:'Company'},{n:'location',l:'Location'},{n:'category',l:'Category',t:'select',o:CATS},{n:'salary',l:'Salary'},{n:'contact',l:'Contact email'},{n:'description',l:'Description',t:'textarea'},{n:'img',l:'Image',t:'file'}],cols:[['Title','title'],['Company','company'],['Location','location'],['Category','category'],['Salary','salary'],['Image','img']],del:1},
  {t:'View Applied Users',k:'applications',where:(r,me)=>r.owner===me.email,cols:[['Applicant','uname'],['Email','user'],['Vacancy','title'],['Date','date'],['Status','status']],status:{o:['Applied','Shortlisted','Selected','Rejected']}}],
 user:[
  {t:'Search Vacancy',k:'vacancies',filters:[{n:'title',l:'Job title'},{n:'location',l:'Location'},{n:'category',l:'All categories',o:CATS}],cols:[['Title','title'],['Company','company'],['Location','location'],['Category','category'],['Salary','salary'],['Details','description']],
   act:{l:'Apply',k:'applications',def:{status:'Applied'},mk:r=>({vid:r.id,title:r.title,owner:r.user}),ok:'Application sent'}},
  {t:'My Applications',k:'applications',own:1,cols:[['Vacancy','title'],['Date','date'],['Status','status']]}]}});
