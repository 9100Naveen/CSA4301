# 21. JobConnect (Online Job Portal)

Features: vacancy posting, director approval, job search with filters and online applications.

## Run
Open `index.html` in a browser. No server or install needed.

## Demo logins
app@job.com / 1234 | dir@job.com / 1234 | admin@job.com / admin123

## Notes
- Front-end only: data is saved in the browser (localStorage). Clear site data to reset.
- Payments, OTP, email and SMS are simulated (demo only).
