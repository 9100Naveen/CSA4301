# 14. ReNewMarket (Second-hand Marketplace)

Listings, search/filter, price negotiation, secure purchase, logistics tracking, feedback, favourites, notifications. Admin: users, categories, commodities, orders.

## Run
Open `index.html` in a browser. No server or install needed.

## Demo logins
Admin: admin@renew.com / admin123 | Users: seller@renew.com or buyer@renew.com / 1234

## Notes
- Front-end only: data is saved in the browser (localStorage). Clear site data to reset.
- Passwords are plain text; payments, OTP, email and SMS are simulated (demo only).
