# 26. Traffic Squad (Penalty Collection)

Features: online case creation with a proof photo, challan viewing and payment, live traffic updates and daily reports.

## Run
Open `index.html` in a browser. No server or install needed.

## Demo logins
user@traffic.com / 1234 | police@traffic.com / 1234 | admin@traffic.com / admin123

## Notes
- Front-end only: data is saved in the browser (localStorage). Clear site data to reset.
- Payments, OTP, email and SMS are simulated (demo only).
