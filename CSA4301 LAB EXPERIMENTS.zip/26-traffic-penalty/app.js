const cc=[['Date','date'],['Vehicle','vehicle'],['Owner',r=>esc(UN(r.owner))],['Offence','offence'],['Location','location'],RS('Fine','fine'),['Proof','proof'],['Status','status']];
runPortal({title:'🚦 Traffic Squad',users:[{name:'Traffic Admin',email:'admin@traffic.com',password:'admin123',role:'admin'},{name:'Inspector Raj',email:'police@traffic.com',password:'1234',role:'police'},{name:'Demo Vehicle Owner',email:'user@traffic.com',password:'1234',role:'user'}],
 regRoles:['user'],hint:'Demo: admin@traffic.com / admin123 · police@traffic.com / 1234 · user@traffic.com / 1234',
 seed:{rules:[{offence:'Signal jumping',fine:1000},{offence:'No helmet',fine:500},{offence:'Over speeding',fine:1500},{offence:'Wrong parking',fine:300}],
  cases:[{user:'police@traffic.com',vehicle:'TN58AB1234',owner:'user@traffic.com',offence:'No helmet',location:'Gandhi Road',fine:500,status:'Unpaid',proof:''}],
  traffic:[{road:'Anna Nagar Main Road',level:'Heavy',note:'Water-logging near signal'},{road:'Alagar Kovil Road',level:'Clear',note:''}]},
 tabs:{admin:[
  {t:'Police Login',type:'users',role:'police',del:1,add:[{n:'name',l:'Officer name'},{n:'email',l:'Login email',t:'email'},{n:'password',l:'Password'}]},
  {t:'Daily Report',type:'report',items:[{l:'Cases filed today',k:'cases',where:r=>r.date===today()},{l:'Fine raised today',fn:()=>rs(CL('cases').filter(r=>r.date===today()).reduce((s,r)=>s+ +r.fine,0))},{l:'Total unpaid cases',k:'cases',where:r=>r.status==='Unpaid'}],groups:[{l:'Cases by offence',k:'cases',by:'offence'}]},
  {t:'All Cases',k:'cases',cols:cc}],
 police:[
  {t:'Rules',k:'rules',fields:[{n:'offence',l:'Offence'},{n:'fine',l:'Fine (₹)',t:'number'}],cols:[['Offence','offence'],RS('Fine','fine')],edit:1,del:1},
  {t:'Create Case',k:'cases',fields:[{n:'vehicle',l:'Vehicle number'},{n:'owner',l:'Owner (login email)',t:'select',o:()=>Auth.users().filter(u=>u.role==='user').map(u=>u.email)},{n:'offence',l:'Offence',t:'select',o:()=>CL('rules').map(r=>r.offence)},{n:'location',l:'Location'},{n:'proof',l:'Proof photo',t:'file'}],
   mk:v=>({fine:+(CL('rules').find(r=>r.offence===v.offence)||{}).fine,status:'Unpaid'}),ok:'Case filed and challan sent to owner',cols:cc},
  {t:'Live Traffic Report',k:'traffic',fields:[{n:'road',l:'Road'},{n:'level',l:'Traffic',t:'select',o:['Clear','Moderate','Heavy']},{n:'note',l:'Update',r:false}],cols:[['Updated','date'],['Road','road'],['Traffic','level'],['Note','note']],del:1},
  {t:'Traffic Map',type:'html',html:()=>`<h3>Google Maps traffic</h3><p><a target="_blank" href="https://www.google.com/maps/@9.9252,78.1198,13z/data=!5m1!1e1">Open live traffic layer</a></p><iframe title="map" loading="lazy" style="width:100%;height:300px;border:0" src="https://www.google.com/maps?q=Madurai+traffic&output=embed"></iframe>`}],
 user:[
  {t:'View Challan',k:'cases',where:(r,me)=>r.owner===me.email&&r.status==='Unpaid',cols:cc,acts:[{l:'Pay fine',patch:{status:'Paid'},ok:'Fine paid'}]},
  {t:'View Case Filed',k:'cases',where:(r,me)=>r.owner===me.email,cols:cc}]}});
