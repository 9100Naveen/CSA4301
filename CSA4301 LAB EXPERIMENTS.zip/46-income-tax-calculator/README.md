# 46. Income Tax Calculator

Features: tax calculation using slabs, admin-editable norms and a downloadable summary.

## Run
Open `index.html` in a browser. No server or install needed.

## Demo logins
No login needed

## Notes
- Front-end only: data is saved in the browser (localStorage). Clear site data to reset.
- Payments, OTP, email and SMS are simulated (demo only).
