# Internet Programming Lab – Experiments 1 to 47
Open any folder's `index.html` in a browser. Each folder has a README with demo logins.
Numbering is consecutive (the lab sheet repeats 28 and 36 and skips 29).
