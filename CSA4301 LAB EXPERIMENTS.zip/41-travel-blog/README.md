# 41. Travel Blog

Features: articles, a destination filter, an interactive map, a photo gallery, comments and social sharing.

## Run
Open `index.html` in a browser. No server or install needed.

## Demo logins
No login needed

## Notes
- Front-end only: data is saved in the browser (localStorage). Clear site data to reset.
- Payments, OTP, email and SMS are simulated (demo only).
