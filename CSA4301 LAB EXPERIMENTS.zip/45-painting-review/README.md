# 45. Painting Rating and Review

Features: painting submission with packages, customer ratings and a positive and negative review summary.

## Run
Open `index.html` in a browser. No server or install needed.

## Demo logins
cust@art.com / 1234 | owner@art.com / 1234 | admin@art.com / admin123

## Notes
- Front-end only: data is saved in the browser (localStorage). Clear site data to reset.
- Payments, OTP, email and SMS are simulated (demo only).
