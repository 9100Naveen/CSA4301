# 13. BlossomGifts

Flowers and gifts by category/occasion, delivery date and time, card message, wishlist, order tracking. Admin: items, prices, inventory, orders.

## Run
Open `index.html` in a browser. No server or install needed.

## Demo logins
Admin: admin@bloom.com / admin123 | Customer: cust@bloom.com / 1234 | Promo: LOYAL10

## Notes
- Front-end only: data is saved in the browser (localStorage). Clear site data to reset.
- Passwords are plain text; payments, OTP, email and SMS are simulated (demo only).
