# 10. StyleHub Fashion Shop

Categories, search/filter, sizes, size guide, wishlist, reviews, cart, checkout, order tracking, return/exchange, flash-sale code. Admin: items, prices, descriptions, customer orders.

## Run
Open `index.html` in a browser. No server or install needed.

## Demo logins
Admin: admin@style.com / admin123 | Customer: cust@style.com / 1234 | Promo: FLASH20

## Notes
- Front-end only: data is saved in the browser (localStorage). Clear site data to reset.
- Passwords are plain text; payments, OTP, email and SMS are simulated (demo only).
