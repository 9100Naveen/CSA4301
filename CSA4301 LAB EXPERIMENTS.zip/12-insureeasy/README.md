# 12. InsureEasy Insurance Management

Admin approves agents; agents create customers, manage policies and send SMS alerts; users view/pay policies, compare plans, get alerts, file claims.

## Run
Open `index.html` in a browser. No server or install needed.

## Demo logins
Admin: admin@ins.com / admin123 | Agent: agent@ins.com / agent123 | Policyholder: user@ins.com / 1234

## Notes
- Front-end only: data is saved in the browser (localStorage). Clear site data to reset.
- Passwords are plain text; payments, OTP, email and SMS are simulated (demo only).
