# 42. Digital Recipe Book

Features: recipe search and filters, serving-size scaling, ratings, favourites, a meal planner, shopping list and printing.

## Run
Open `index.html` in a browser. No server or install needed.

## Demo logins
No login needed

## Notes
- Front-end only: data is saved in the browser (localStorage). Clear site data to reset.
- Payments, OTP, email and SMS are simulated (demo only).
