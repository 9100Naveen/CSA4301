# 40. QuickCart Online Store

Features: a product catalogue, search and filters, cart, checkout, order confirmation and tracking.

## Run
Open `index.html` in a browser. No server or install needed.

## Demo logins
shopper@store.com / 1234 | admin@store.com / admin123

## Notes
- Front-end only: data is saved in the browser (localStorage). Clear site data to reset.
- Payments, OTP, email and SMS are simulated (demo only).
