Auth.seed([{name:'Election Officer',email:'admin@vote.com',password:'admin123',role:'admin'}]);
if(!DB.get('init')){DB.set('init',1);DB.set('open',true);DB.set('votes',[]);
 DB.set('cands',[{id:'c1',name:'Priya Nair',party:'Unity Party',ward:'1'},{id:'c2',name:'Arun Kumar',party:'People First',ward:'1'},{id:'c3',name:'Meera Joseph',party:'Unity Party',ward:'2'},{id:'c4',name:'Sanjay Rao',party:'Green Alliance',ward:'2'}]);
 DB.set('voters',[{id:'V1001',name:'Asha',ward:'1',voted:false},{id:'V1002',name:'Ravi',ward:'1',voted:false},{id:'V1003',name:'Meena',ward:'2',voted:false}])}
const CA=()=>DB.get('cands',[]),VO=()=>DB.get('voters',[]);let OTP=null,PENDING=null;
function start(){const me=Auth.me();if(me)return shell('🗳 VoteOnline – Admin',{Candidates:candView,Voters:voterAdmin,Election:electionView,Results:resultView},me);
 if(DB.get('vs'))return voter();
 $('#app').innerHTML=`<header><h1>🗳 VoteOnline</h1></header><div class="grid" style="max-width:820px;margin:20px auto;padding:0 14px"><div class="card auth" style="margin:0"><h2>Voter login</h2><form id="vf"><label>Voter ID</label><input name="vid" placeholder="e.g. V1001" required><button class="btn" style="width:100%">Get OTP</button></form><div id="otpbox" class="hide"><div class="card">📱 Demo SMS: your OTP is <b id="otp"></b></div><form id="of"><label>Enter OTP</label><input name="otp" inputmode="numeric" required><button class="btn" style="width:100%">Verify & login</button></form></div><small>Demo voter IDs: V1001, V1002, V1003</small></div><div id="ad"></div></div>`;
 mountAuth($('#ad'),{title:'Admin login',noReg:true,hint:'Demo: admin@vote.com / admin123'},start);$('#ad .auth').style.margin='0';
 $('#vf').onsubmit=e=>{const f=fd(e),v=VO().find(x=>x.id===f.vid.trim().toUpperCase());if(!v)return toast('Voter ID not found');PENDING=v.id;OTP=String(Math.floor(100000+Math.random()*900000));$('#otp').textContent=OTP;$('#otpbox').classList.remove('hide')};
 $('#of').onsubmit=e=>{const f=fd(e);if(f.otp!==OTP)return toast('Wrong OTP');OTP=null;DB.set('vs',PENDING);start()}}
function voter(m){const v=VO().find(x=>x.id===DB.get('vs'));
 document.body.innerHTML=`<header><h1>🗳 VoteOnline</h1><span>${esc(v.name)} · Ward ${v.ward} <button class="btn sm sec" style="color:inherit;border-color:currentColor" onclick="DB.del('vs');location.reload()">Logout</button></span></header><main id="mn"></main>`;
 const mn=$('#mn');
 if(!DB.get('open'))return mn.innerHTML='<div class="card"><h3>Voting is closed</h3><p>The election is not open right now.</p></div>';
 if(v.voted)return mn.innerHTML='<div class="card"><h3 class="ok">✔ Your vote has been recorded</h3><p>Thank you for voting. You cannot vote again.</p></div>';
 mn.innerHTML=`<div class="card"><h3>Select your candidate (Ward ${v.ward})</h3><form id="f">${CA().filter(c=>c.ward===v.ward).map(c=>`<label style="display:block;padding:10px;border:1px solid var(--bd);border-radius:8px;margin:8px 0;color:var(--tx)"><input type="radio" name="c" value="${c.id}" required style="width:auto"> <b>${esc(c.name)}</b> — ${esc(c.party)}</label>`).join('')}<button class="btn">Submit vote</button></form></div>`;
 $('#f').onsubmit=e=>{const f=fd(e);if(!confirm('Submit your vote? This cannot be changed.'))return;const vs=VO();vs.find(x=>x.id===v.id).voted=true;DB.set('voters',vs);const vt=DB.get('votes',[]);vt.push({cid:f.c,ward:v.ward});DB.set('votes',vt);
  mn.innerHTML=`<div class="card"><h3 class="ok">✔ Vote submitted</h3><p>Confirmation ref: <b>${uid().toUpperCase()}</b></p></div>`}}
function candView(m){m.innerHTML=`<div class="card"><h3>Create candidate</h3><form id="f" class="row"><input name="name" placeholder="Candidate name" required><input name="party" placeholder="Party"><input name="ward" placeholder="Ward no." required><button class="btn">Add</button></form></div><div class="card">${tbl(['Name','Party','Ward',''],CA().map(c=>[esc(c.name),esc(c.party),c.ward,`<button class="btn sm red" onclick="delC('${c.id}')">Delete</button>`]))}</div>`;
 $('#f').onsubmit=e=>{const c=CA();c.push({id:uid(),...fd(e)});DB.set('cands',c);refresh()}}
function delC(id){DB.set('cands',CA().filter(c=>c.id!==id));refresh()}
function voterAdmin(m){m.innerHTML=`<div class="card"><h3>Create voter</h3><form id="f" class="row"><input name="id" placeholder="Voter ID" required><input name="name" placeholder="Name" required><input name="ward" placeholder="Ward (allocate)" required><button class="btn">Add</button></form></div><div class="card"><h3>Import voter list</h3><textarea id="csv" rows="4" placeholder="One voter per line: VoterID,Name,Ward"></textarea><button class="btn sec" id="imp">Import</button></div><div class="card"><h3>Voter list</h3>${tbl(['ID','Name','Ward','Voted',''],VO().map(v=>[v.id,esc(v.name),v.ward,v.voted?'Yes':'No',`<button class="btn sm" onclick="editV('${v.id}')">Update</button> <button class="btn sm red" onclick="delV('${v.id}')">Delete</button>`]))}</div>`;
 const add=v=>{const l=VO();if(l.some(x=>x.id===v.id))return false;l.push({...v,id:v.id.toUpperCase(),voted:false});DB.set('voters',l);return true};
 $('#f').onsubmit=e=>{if(!add(fd(e)))toast('Voter ID exists');refresh()};
 $('#imp').onclick=()=>{let n=0;$('#csv').value.split('\n').forEach(l=>{const[a,b,c]=l.split(',').map(s=>s.trim());if(a&&b&&c&&add({id:a,name:b,ward:c}))n++});toast(n+' voters imported');refresh()}}
function editV(id){const l=VO(),v=l.find(x=>x.id===id);v.name=prompt('Name',v.name)||v.name;v.ward=prompt('Ward',v.ward)||v.ward;DB.set('voters',l);refresh()}
function delV(id){DB.set('voters',VO().filter(v=>v.id!==id));refresh()}
function electionView(m){const o=DB.get('open');m.innerHTML=`<div class="card"><h3>Election status: <span class="${o?'ok':'bad'}">${o?'OPEN':'CLOSED'}</span></h3><button class="btn" onclick="DB.set('open',${!o});refresh()">${o?'Close':'Open'} voting</button> <button class="btn red" onclick="resetE()">Reset all votes</button></div>`}
function resetE(){if(confirm('Delete all votes?')){DB.set('votes',[]);DB.set('voters',VO().map(v=>({...v,voted:false})));toast('Votes reset');refresh()}}
function resultView(m){const vt=DB.get('votes',[]),wards=[...new Set(CA().map(c=>c.ward))].sort();
 m.innerHTML=`<div class="card"><h3>Turnout</h3><p>${vt.length} of ${VO().length} voters (${VO().length?Math.round(vt.length*100/VO().length):0}%)</p></div>`+wards.map(w=>{const cs=CA().filter(c=>c.ward===w).map(c=>({...c,n:vt.filter(v=>v.cid===c.id).length})),max=Math.max(...cs.map(c=>c.n)),tot=cs.reduce((s,c)=>s+c.n,0)||1;
  return`<div class="card"><h3>Ward ${w}</h3>${cs.map(c=>`<div>${esc(c.name)} (${esc(c.party)}) — <b>${c.n}</b> ${c.n===max&&max>0?'<span class="tag">Leading</span>':''}<div class="bar" style="width:${c.n*100/tot}%"></div></div>`).join('<br>')}</div>`}).join('')}
start();
