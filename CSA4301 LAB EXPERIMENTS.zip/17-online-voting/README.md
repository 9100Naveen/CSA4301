# 17. VoteOnline E-Voting
Open `index.html`. Admin: admin@vote.com / admin123 | Voter IDs: V1001, V1002, V1003 (OTP is shown on screen).
Admin creates candidates, voter list, imports voters, allocates wards, opens/closes voting and views results. Voter logs in with Voter ID + OTP and votes once.
