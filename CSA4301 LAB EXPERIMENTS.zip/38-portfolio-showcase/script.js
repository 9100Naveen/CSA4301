const $=s=>document.querySelector(s);
const skills=['JavaScript','Python','SQL','React','Node.js','HTML/CSS','Git'];
const timeline=[['2021–2025','B.E. Computer Science, Government College of Technology'],['2024','Intern – web developer, Pixel Works'],['2025','Final-year project: library management system'],['2026','Freelance projects for local businesses']];
const tests=[['“Arjun delivered the portal two weeks early and documented everything.”','Dr. S. Kumar, project guide'],['“Calm under deadlines, and great at explaining technical choices.”','Nisha P., intern lead']];
const projects=[{t:'Library Manager',tech:'JavaScript',d:'Catalogue, issue/return and fines for a college library.',demo:'#',src:'#'},{t:'Hotel Booking',tech:'JavaScript',d:'Room availability and booking rules with an admin panel.',demo:'#',src:'#'},{t:'Expense Tracker API',tech:'Python',d:'REST API with SQLite and token auth.',demo:'#',src:'#'},{t:'Campus Events',tech:'React',d:'Event listing with RSVP and reminders.',demo:'#',src:'#'}];
const posts=[['Why I validate on both client and server','Client checks make forms friendly; server checks keep data safe. I write the rules once as a schema and reuse them in both places.'],['Notes from my first internship','Read the codebase before changing it, ask small questions early, and write the test before the fix.']];
$('#skills').innerHTML=skills.map(s=>`<span>${s}</span>`).join('');
$('#tl').innerHTML=timeline.map(t=>`<li><b>${t[0]}</b> — ${t[1]}</li>`).join('');
$('#tm').innerHTML=tests.map(t=>`<div class="card"><p>${t[0]}</p><b>${t[1]}</b></div>`).join('');
const techs=['All',...new Set(projects.map(p=>p.tech))];
function draw(f){$('#flt').innerHTML=techs.map(t=>`<button class="${t===f?'on':''}">${t}</button>`).join('');$('#flt').querySelectorAll('button').forEach(b=>b.onclick=()=>draw(b.textContent));
 $('#pj').innerHTML=projects.filter(p=>f==='All'||p.tech===f).map(p=>`<div class="card"><h3>${p.t}</h3><p>${p.d}</p><small>${p.tech}</small><p><a href="${p.demo}">Live demo</a><a href="${p.src}">Source code</a></p></div>`).join('')}
draw('All');
const resume=`ARJUN MENON — Full-Stack Developer\narjun@example.com\n\nSKILLS\n${skills.join(', ')}\n\nEXPERIENCE & EDUCATION\n${timeline.map(t=>t.join(' – ')).join('\n')}\n\nPROJECTS\n${projects.map(p=>p.t+': '+p.d).join('\n')}`;
$('#rs').innerHTML=`<h3>Skills</h3><p>${skills.join(' · ')}</p><h3>Career milestones</h3><ul>${timeline.map(t=>`<li><b>${t[0]}</b> – ${t[1]}</li>`).join('')}</ul><h3>Projects</h3><ul>${projects.map(p=>`<li><b>${p.t}</b>: ${p.d}</li>`).join('')}</ul>`;
$('#dl').onclick=()=>{const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([resume],{type:'text/plain'}));a.download='resume.txt';a.click()};
$('#bl').innerHTML=posts.map(p=>`<details><summary>${p[0]}</summary><p>${p[1]}</p></details>`).join('');
$('#cf').onsubmit=e=>{e.preventDefault();const f=Object.fromEntries(new FormData(e.target));try{const l=JSON.parse(localStorage.getItem('pf_msgs')||'[]');l.push(f);localStorage.setItem('pf_msgs',JSON.stringify(l))}catch(x){}$('#cm').textContent='Thanks '+f.name+'! Your message was saved. (In a real site this posts to a server.)';e.target.reset()};
$('#th').onclick=()=>{const r=document.documentElement,d=r.dataset.theme==='dark'||(!r.dataset.theme&&matchMedia('(prefers-color-scheme:dark)').matches);r.dataset.theme=d?'light':'dark'};
