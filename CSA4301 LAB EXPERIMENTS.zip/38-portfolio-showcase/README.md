# MyProfessionalShowcase (portfolio)
Open `index.html`. Edit the sample data at the top of `script.js` with your own details. Includes project filters, resume download/print, blog, contact form and dark mode.
