const ok=r=>(Auth.users().find(u=>u.email===r.user)||{}).approved;
const geo=r=>{const q=encodeURIComponent(r.shop+' '+r.area);return `<a target="_blank" href="https://www.google.com/maps/search/?api=1&query=${q}">Open location</a><details><summary>Map</summary><iframe title="map" loading="lazy" style="width:240px;height:150px;border:0" src="https://www.google.com/maps?q=${q}&output=embed"></iframe></details>`};
const bf=[{n:'shop',l:'Garage / business name'},{n:'area',l:'Area / city'},{n:'specialty',l:'Specialty',t:'select',o:['Car','Bike','Truck','Tyre / puncture','Towing']},{n:'phone',l:'Phone'},{n:'license',l:'Licence number'}];
runPortal({title:'🔧 Road Assist',users:[{name:'Road Admin',email:'admin@road.com',password:'admin123',role:'admin'},{name:'Ravi Motors',email:'mech@road.com',password:'1234',role:'mechanic',approved:true},{name:'Demo Driver',email:'user@road.com',password:'1234',role:'user',phone:'9876500005'}],
 regRoles:['user','mechanic'],regExtra:regExtraPhone,hint:'Demo: admin@road.com / admin123 · mech@road.com / 1234 · user@road.com / 1234',
 gate:me=>me.role==='mechanic'&&!me.approved?'Approval pending: only licensed mechanics are listed. The admin must approve you.':'',
 seed:{businesses:[{user:'mech@road.com',shop:'Ravi Motors',area:'Madurai',specialty:'Car',phone:'9876500006',license:'TN-LIC-1021',address:'Alanganallur Road'},{user:'mech@road.com',shop:'Quick Tyre Care',area:'Theni',specialty:'Tyre / puncture',phone:'9876500007',license:'TN-LIC-1022'}],feedback:[{user:'user@road.com',shop:'Ravi Motors',rating:5,text:'Reached in 20 minutes.'}]},
 tabs:{admin:[{t:'Provide Approval',type:'users',role:'mechanic',cols:[['Name','name'],['Email','email'],['Approved',r=>r.approved?'<span class="ok">Licensed – listed</span>':'Pending']],toggle:{key:'approved'},del:1}],
 user:[
  {t:'Search Mechanic',k:'businesses',where:ok,filters:[{n:'area',l:'Location'},{n:'specialty',l:'Any type',o:['Car','Bike','Truck','Tyre / puncture','Towing']}],cols:[['Mechanic','shop'],['Area','area'],['Specialty','specialty'],['Phone','phone'],['Google location',geo]]},
  {t:'Post Feedback',k:'feedback',own:1,fields:[{n:'shop',l:'Mechanic',t:'select',o:()=>CL('businesses').map(b=>b.shop)},{n:'rating',l:'Rating (1-5)',t:'number'},{n:'text',l:'Feedback'}],cols:[['Mechanic','shop'],['Rating',r=>'★'.repeat(r.rating)],['Feedback','text']]},
  {t:'My Profile',type:'profile',fields:['phone']}],
 mechanic:[
  {t:'Post Business',k:'businesses',own:1,fields:bf,cols:[['Business','shop'],['Area','area'],['Specialty','specialty'],['Licence','license']]},
  {t:'Manage Business',k:'businesses',own:1,fields:bf,form:'Update business',cols:[['Business','shop'],['Area','area'],['Phone','phone']],edit:1,del:1},
  {t:'View Feedback',k:'feedback',where:(r,me)=>CL('businesses').some(b=>b.user===me.email&&b.shop===r.shop),cols:[W('Customer'),['Mechanic','shop'],['Rating',r=>'★'.repeat(r.rating)],['Feedback','text']]}]}});
