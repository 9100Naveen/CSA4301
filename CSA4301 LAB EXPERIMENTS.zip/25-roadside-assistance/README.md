# 25. On-Road Vehicle Breakdown Assistance

Features: licensed mechanic approval, mechanic search with Google location and feedback.

## Run
Open `index.html` in a browser. No server or install needed.

## Demo logins
user@road.com / 1234 | mech@road.com / 1234 | admin@road.com / admin123

## Notes
- Front-end only: data is saved in the browser (localStorage). Clear site data to reset.
- Payments, OTP, email and SMS are simulated (demo only).
