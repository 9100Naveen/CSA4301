# 43. Electricity Bill Payment

Features: slab-based tariff calculation, a fine for late payment, bill payment and receipts.

## Run
Open `index.html` in a browser. No server or install needed.

## Demo logins
cust@eb.com / 1234 | admin@eb.com / admin123

## Notes
- Front-end only: data is saved in the browser (localStorage). Clear site data to reset.
- Payments, OTP, email and SMS are simulated (demo only).
