const slides=[['🍷','The cellar',"#3b1d24"],['🥩','Wood-fire lamb',"#3a2616"],['🍰','Dessert trolley',"#2a2038"],['🕯','Candlelit dining room',"#1f2b2a"]];
$s=document.getElementById.bind(document);
$s('slides').innerHTML=slides.map((s,i)=>`<div class="slide${i?'':' on'}" style="background:${s[2]}">${s[0]}<small>${s[1]}</small></div>`).join('');
let cur=0;setInterval(()=>{const l=document.querySelectorAll('.slide');l[cur].classList.remove('on');cur=(cur+1)%l.length;l[cur].classList.add('on')},4000);
const menu={Appetizers:[['🥗','Burrata & heirloom tomato','Basil oil, aged balsamic, toasted sourdough',620],['🍤','Tiger prawns','Garlic butter, chilli, lemon',780],['🍄','Wild mushroom velouté','Truffle cream, chive',540]],'Main courses':[['🥩','Wood-fire lamb rack','Rosemary jus, pomme purée, charred greens',1650],['🐟','Pan-seared sea bass','Saffron beurre blanc, fennel, new potatoes',1450],['🍝','Wild mushroom risotto','Arborio, parmesan, thyme (vegetarian)',980]],Desserts:[['🍫','Dark chocolate fondant','Warm centre, vanilla bean ice cream',520],['🍮','Crème brûlée','Madagascan vanilla, caramelised sugar',480],['🍓','Strawberry pavlova','Chantilly cream, berry coulis',500]]};
const tabs=$s('tabs'),dishes=$s('dishes');
function show(c){tabs.querySelectorAll('button').forEach(b=>b.classList.toggle('on',b.textContent===c));dishes.innerHTML=menu[c].map(d=>`<div class="dish"><span class="i">${d[0]}</span><b>${d[1]}<span>₹${d[3]}</span></b><p>${d[2]}</p></div>`).join('')}
Object.keys(menu).forEach(c=>{const b=document.createElement('button');b.textContent=c;b.onclick=()=>show(c);tabs.append(b)});show('Appetizers');
$s('gal').innerHTML=['🍷','🥂','🍽','🔥','🌿','🍰','🕯','🧀'].map(e=>`<div>${e}</div>`).join('');
const rd=$s('rd');rd.min=new Date().toISOString().slice(0,10);
const store=(k,v)=>{try{const l=JSON.parse(localStorage.getItem(k)||'[]');l.push(v);localStorage.setItem(k,JSON.stringify(l))}catch(e){}};
$s('rf').onsubmit=e=>{e.preventDefault();const f=Object.fromEntries(new FormData(e.target));store('gh_reservations',f);$s('rmsg').textContent=`Thank you, ${f.name}. Table for ${f.guests} on ${f.date} at ${f.time} is reserved.`;e.target.reset()};
$s('cf').onsubmit=e=>{e.preventDefault();store('gh_messages',Object.fromEntries(new FormData(e.target)));$s('cmsg').textContent='Message received. We will reply within one working day.';e.target.reset()};
