# Gourmet Haven (restaurant website)
Open `index.html`. Carousel, tabbed menu, reservation form, offers, about, gallery, testimonials, contact form with Google Map. Reservations and messages are saved in localStorage.
