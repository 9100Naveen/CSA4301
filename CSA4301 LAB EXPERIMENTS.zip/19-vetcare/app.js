const ANI=['Cow','Buffalo','Goat','Sheep','Poultry','Dog'],docs=()=>Auth.users().filter(u=>u.role==='doctor').map(u=>u.name);
const cmpCols=[['Date','date'],['Animal','animal'],['Area','area'],['Symptoms','symptoms'],['Photo','media'],['Status','status']];
runPortal({title:'🐄 VetCure',users:[{name:'Demo Farmer',email:'farmer@vet.com',password:'1234',role:'user',phone:'9876500001',village:'Melur'},{name:'Dr. Kavitha',email:'doc@vet.com',password:'1234',role:'doctor',clinic:'Govt. Veterinary Hospital',phone:'9876500002'}],
 regRoles:['user','doctor'],regExtra:regExtraPhone,hint:'Demo: farmer@vet.com / 1234 · doc@vet.com / 1234',
 seed:{cures:[{disease:'Foot and mouth disease',animal:'Cattle',cure:'Isolate the animal, antiseptic wash, vaccination'},{disease:'Mastitis',animal:'Cow',cure:'Antibiotic course, udder hygiene, warm compress'},{disease:'Bloat',animal:'Goat',cure:'Anti-bloat medicine and a vet check'}],
  news:[{title:'Free vaccination camp',body:'Govt. CVH camp this Saturday at the panchayat office.'},{title:'Monsoon care tips',body:'Keep sheds dry and clean to avoid foot rot.'}],
  complaints:[{user:'farmer@vet.com',animal:'Cow',area:'Madurai',symptoms:'Fever and reduced milk',status:'Open',solution:''},{user:'farmer@vet.com',animal:'Goat',area:'Theni',symptoms:'Swollen belly',status:'Solved',solution:'Give anti-bloat medicine'}],payments:[],feedback:[]},
 tabs:{user:[
  {t:'Post Complaint',k:'complaints',own:1,def:{status:'Open',solution:''},form:'Send animal symptoms to the doctor',fields:[{n:'animal',l:'Animal',t:'select',o:ANI},{n:'area',l:'Area / village'},{n:'symptoms',l:'Signs and symptoms',t:'textarea'},{n:'media',l:'Photo (optional)',t:'file'}],cols:cmpCols},
  {t:'My Complaint Status',k:'complaints',own:1,cols:[...cmpCols,['Doctor solution','solution']]},
  {t:'Vetcure Details',k:'cures',filters:[{n:'disease',l:'Search disease'}],cols:[['Disease','disease'],['Animal','animal'],['Cure / prescription','cure']]},
  {t:'News',k:'news',cols:[['Date','date'],['Title','title'],['Details','body']]},
  {t:'Doctors',type:'users',role:'doctor',cols:[['Doctor','name'],['Clinic','clinic'],['Phone','phone']]},
  {t:'Report',type:'report',groups:[{l:'Complaints by area (disease analysis)',k:'complaints',by:'area'},{l:'Complaints by animal',k:'complaints',by:'animal'}]},
  {t:'Feedback',k:'feedback',own:1,fields:[{n:'text',l:'Feedback',t:'textarea'}],cols:[['Date','date'],['Feedback','text']]},
  {t:'Payment',k:'payments',own:1,fields:[{n:'doctor',l:'Doctor',t:'select',o:docs},{n:'amount',l:'Amount (₹)',t:'number'},{n:'method',l:'Mode',t:'select',o:['Bank transfer','EasyPaisa / UPI','Govt. CVH (free)']}],cols:[['Date','date'],['Doctor','doctor'],RS('Amount','amount'),['Mode','method']]},
  {t:'My Profile',type:'profile',fields:['phone','village']}],
 doctor:[
  {t:'Complaints',k:'complaints',title:'View complaints and post solution',cols:[W('Farmer'),...cmpCols],acts:[{l:'Post solution',ask:[{n:'solution',l:'Solution / prescription'}],patch:{status:'Solved'}}]},
  {t:'Manage Cure',k:'cures',fields:[{n:'disease',l:'Disease'},{n:'animal',l:'Animal'},{n:'cure',l:'Cure / prescription'}],cols:[['Disease','disease'],['Animal','animal'],['Cure','cure']],edit:1,del:1},
  {t:'Manage News',k:'news',fields:[{n:'title',l:'Title'},{n:'body',l:'Details',t:'textarea'}],cols:[['Date','date'],['Title','title'],['Details','body']],del:1},
  {t:'User Details',type:'users',role:'user',cols:[['Name','name'],['Email','email'],['Phone','phone'],['Village','village']]},
  {t:'Payments',k:'payments',cols:[['Date','date'],W('Farmer'),['Doctor','doctor'],RS('Amount','amount'),['Mode','method']]},
  {t:'Feedback Details',k:'feedback',cols:[['Date','date'],W('Farmer'),['Feedback','text']]}]}});
