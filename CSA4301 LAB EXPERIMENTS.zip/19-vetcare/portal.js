/* Shared role-based portal engine (forms, tables, approvals). Each app.js supplies a configuration. */
let C;const DEF={};
const CL=k=>DB.get('c_'+k,[]),SC=(k,v)=>DB.set('c_'+k,v),ME=()=>Auth.me()||{email:'guest',name:'Guest',role:'visitor'};
const UN=e=>(Auth.users().find(u=>u.email===e)||{}).name||e||'-';
const isImg=v=>typeof v==='string'&&v.startsWith('data:image');
const W=(l,k='user')=>[l,r=>esc(UN(r[k]))],RS=(l,k)=>[l,r=>rs(r[k])];
const qrBox=(id,t)=>`<div id="qr_${id}" data-t="${esc(t)}"><small>${esc(t)}</small></div>`;
const drawQR=()=>$$('[id^=qr_]').forEach(el=>{if(window.QRCode&&!el.dataset.d){el.dataset.d=1;el.innerHTML='';new QRCode(el,{text:el.dataset.t,width:100,height:100})}});
function runPortal(cfg){C=cfg;Auth.seed(C.users);for(const[k,v]of Object.entries(C.seed||{}))if(DB.get('c_'+k)==null)SC(k,v.map((r,i)=>({id:'s'+k+i,user:C.users[0].email,date:today(),...r})));portalStart()}
function portalStart(){const me=Auth.me(),au=()=>({regRoles:C.regRoles,hint:C.hint,extra:C.regExtra});
 if(!me){if(C.pub){const T={};Object.entries(C.pub).forEach(([n,d])=>T[n]=m=>draw(m,{t:n,...d}));T['Login / Register']=m=>{m.innerHTML='<div id="ah"></div>';mountAuth($('#ah'),au(),portalStart)};return shell(C.title,T,{name:'Guest',role:'visitor'})}
  return mountAuth($('#app'),au(),portalStart)}
 if(C.gate){const g=C.gate(me);if(g){document.body.innerHTML=`<div class="card auth"><h2>${g}</h2><button class="btn" onclick="Auth.logout()">Logout</button></div>`;return}}
 const T={};(C.tabs[me.role]||[]).forEach(d=>T[d.t]=m=>draw(m,d));shell(C.title,T,me)}
function draw(m,d){DEF[d.t]=d;const f={users:usersT,html:(m,d)=>m.innerHTML=`<div class="card">${typeof d.html==='function'?d.html():d.html}</div>`,custom:(m,d)=>d.fn(m),profile:profT,report:repT}[d.type];(f||manage)(m,d)}
const cell=(r,c)=>{if(typeof c[1]==='function')return c[1](r)??'';const v=r[c[1]];return isImg(v)?`<img src="${v}" alt="" style="max-width:90px;border-radius:6px">`:esc(v)};
const fh=f=>`<div><label>${f.l}</label>${f.t==='select'?`<select name="${f.n}">${opt(typeof f.o==='function'?f.o():f.o)}</select>`:f.t==='textarea'?`<textarea name="${f.n}"></textarea>`:`<input name="${f.n}" type="${f.t==='doc'?'file':f.t||'text'}" ${f.t==='file'?'accept="image/*"':''} ${f.r===false||f.t==='file'||f.t==='doc'?'':'required'}>`}</div>`;
function readForm(form,fields,cb){const f=Object.fromEntries(new FormData(form)),fs=fields.filter(x=>x.t==='file'||x.t==='doc');let n=fs.length;if(!n)return cb(f);fs.forEach(x=>{const file=f[x.n];if(x.t==='doc'){f[x.n]=file?file.name:'';--n||cb(f)}else if(file&&file.size){const r=new FileReader();r.onload=()=>{f[x.n]=r.result;--n||cb(f)};r.readAsDataURL(file)}else{f[x.n]='';--n||cb(f)}})}
function manage(m,d){const me=ME(),rows=()=>CL(d.k).filter(r=>(!d.own||r.user===me.email)&&(!d.where||d.where(r,me))),hasAct=d.del||d.edit||d.status||(d.acts||[]).length||d.act,fl=d.filters||[];
 m.innerHTML=(d.fields?`<div class="card"><h3>${d.form||'Add new'}</h3><form id="f"><div class="row">${d.fields.map(fh).join('')}</div><button class="btn">${d.btn||'Save'}</button></form></div>`:'')+`${d.noTable?'':'<div class="card">'}<h3 ${d.noTable?'hidden':''}>${d.title||d.t}</h3>${d.intro||''}${fl.length?`<div class="row">${fl.map((f,i)=>f.o?`<select id="fl${i}">${opt(typeof f.o==='function'?f.o():f.o,f.l)}</select>`:`<input id="fl${i}" placeholder="${f.l}">`).join('')}</div>`:''}<div id="tb"></div>${d.noTable?'':'</div>'}`;
 const dr=()=>{if(d.noTable)return;let L=rows();fl.forEach((f,i)=>{const v=$('#fl'+i).value.toLowerCase();if(v)L=L.filter(r=>f.fn?f.fn(r,v):String(r[f.n]??'').toLowerCase().includes(v))});
  $('#tb').innerHTML=tbl([...d.cols.map(c=>c[0]),...(hasAct?['']:[])],L.slice().reverse().map(r=>[...d.cols.map(c=>cell(r,c)),...(hasAct?[acts(r,d)]:[])]));drawQR()};
 fl.forEach((f,i)=>$('#fl'+i).oninput=dr);dr();
 if(d.fields)$('#f').onsubmit=e=>{e.preventDefault();readForm(e.target,d.fields,v=>{const err=d.check&&d.check(v,me);if(err)return toast(err);SC(d.k,[...CL(d.k),{id:uid(),user:me.email,uname:me.name,date:today(),...(d.def||{}),...v,...(d.mk?d.mk(v,me):{})}]);toast(d.ok||'Saved');refresh()})}}
function acts(r,d){let h='';const sn=d.status&&(d.status.n||'status');
 if(d.status)h+=`<select onchange="patch('${d.k}','${r.id}','${sn}',this.value)">${d.status.o.map(s=>`<option${s===r[sn]?' selected':''}>${s}</option>`).join('')}</select> `;
 (d.acts||[]).forEach((a,i)=>{if(!a.show||a.show(r))h+=`<button class="btn sm" onclick="act('${esc(d.t)}','${r.id}',${i})">${a.l}</button> `});
 if(d.act&&(!d.act.show||d.act.show(r)))h+=`<button class="btn sm" onclick="doAct('${esc(d.t)}','${r.id}')">${d.act.l}</button> `;
 if(d.edit)h+=`<button class="btn sm sec" onclick="editR('${esc(d.t)}','${r.id}')">Edit</button> `;
 if(d.del)h+=`<button class="btn sm red" onclick="delR('${d.k}','${r.id}')">Delete</button>`;return h}
function patch(k,id,f,v){SC(k,CL(k).map(r=>r.id===id?{...r,[f]:v}:r));toast('Updated');refresh()}
function delR(k,id){if(confirm('Delete this record?')){SC(k,CL(k).filter(r=>r.id!==id));refresh()}}
function act(t,id,i){const d=DEF[t],a=d.acts[i],r=CL(d.k).find(x=>x.id===id);let p={...(a.patch||{})};for(const q of a.ask||[]){const v=prompt(q.l,q.def??'');if(v===null)return;p[q.n]=v}
 const err=a.check&&a.check(r,p);if(err)return toast(err);if(a.fn)p={...p,...a.fn(r,p)};SC(d.k,CL(d.k).map(x=>x.id===id?{...x,...p}:x));if(a.run)a.run(r,p);toast(a.ok||'Done');refresh()}
function doAct(t,id){const d=DEF[t],a=d.act,r=CL(d.k).find(x=>x.id===id),me=ME();if(!Auth.me())return toast('Please login first');const ans={};for(const q of a.ask||[]){const v=prompt(q.l,typeof q.def==='function'?q.def():q.def??'');if(v===null)return;ans[q.n]=v}
 const err=a.check&&a.check(r,ans,me);if(err)return toast(err);SC(a.k,[...CL(a.k),{id:uid(),user:me.email,uname:me.name,date:today(),...(a.def||{}),...a.mk(r,ans,me)}]);toast(a.ok||'Done');refresh()}
function editR(t,id){const d=DEF[t],r=CL(d.k).find(x=>x.id===id),p={};for(const f of d.fields.filter(x=>x.t!=='file'&&x.t!=='doc')){const v=prompt(f.l,r[f.n]??'');if(v===null)return;p[f.n]=f.t==='number'?+v:v}SC(d.k,CL(d.k).map(x=>x.id===id?{...x,...p}:x));refresh()}
function usersT(m,d){const cs=d.cols||[['Name','name'],['Email','email']],L=Auth.users().filter(u=>u.role===d.role);
 m.innerHTML=`<div class="card"><h3>${d.title||d.t}</h3>${d.add?`<form id="f" class="row">${d.add.map(fh).join('')}<button class="btn">Create</button></form>`:''}${tbl([...cs.map(c=>c[0]),''],L.map(u=>[...cs.map(c=>cell(u,c)),(d.toggle?`<button class="btn sm ${u[d.toggle.key]?'red':''}" onclick="tog('${u.email}','${d.toggle.key}')">${u[d.toggle.key]?'Revoke':d.toggle.l||'Approve'}</button> `:'')+(d.del?`<button class="btn sm red" onclick="delU('${u.email}')">Delete</button>`:'')]))}</div>`;
 if(d.add)$('#f').onsubmit=e=>{const f=fd(e);if(Auth.users().some(u=>u.email===f.email))return toast('Email already exists');DB.set('users',[...Auth.users(),{...f,role:d.role}]);refresh()}}
function tog(e,k){const u=Auth.users().find(x=>x.email===e);u[k]=!u[k];Auth.save(u);refresh()}
function delU(e){if(confirm('Delete this account?')){DB.set('users',Auth.users().filter(u=>u.email!==e));refresh()}}
function profT(m,d){const u=Auth.me();m.innerHTML=`<div class="card"><h3>${d.t}</h3><form id="f"><label>Name</label><input name="name" value="${esc(u.name)}"><label>Email</label><input value="${esc(u.email)}" disabled>${d.fields.map(k=>`<label>${k[0].toUpperCase()+k.slice(1)}</label><input name="${k}" value="${esc(u[k]||'')}">`).join('')}<button class="btn">Save profile</button></form></div>`;$('#f').onsubmit=e=>{Auth.save({...u,...fd(e)});toast('Profile saved')}}
function repT(m,d){m.innerHTML=`<div class="grid">${(d.items||[]).map(i=>`<div class="card"><small>${i.l}</small><p class="big">${i.fn?i.fn():CL(i.k).filter(r=>!i.where||i.where(r)).length}</p></div>`).join('')}</div><br>${(d.groups||[]).map(g=>`<div class="card"><h3>${g.l}</h3>${tbl([g.by||'Group','Count'],Object.entries(CL(g.k).reduce((a,r)=>{const x=(g.fn?g.fn(r):r[g.by])||'-';a[x]=(a[x]||0)+1;return a},{})).map(([a,b])=>[esc(a),b]))}</div>`).join('')}`}
const regExtraPhone='<label>Phone</label><input name="phone">';
