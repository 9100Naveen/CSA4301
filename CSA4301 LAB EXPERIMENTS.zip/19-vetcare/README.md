# 19. VetCure (Veterinary Support)

Features: animal complaint posting, doctor solutions, cure and news management, payments and disease reports.

## Run
Open `index.html` in a browser. No server or install needed.

## Demo logins
farmer@vet.com / 1234 | doc@vet.com / 1234

## Notes
- Front-end only: data is saved in the browser (localStorage). Clear site data to reset.
- Payments, OTP, email and SMS are simulated (demo only).
