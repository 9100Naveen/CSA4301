# 24. Wanderlust Travels

Features: tourism, food, hotel and route information with accommodation booking.

## Run
Open `index.html` in a browser. No server or install needed.

## Demo logins
user@travel.com / 1234 | admin@travel.com / admin123

## Notes
- Front-end only: data is saved in the browser (localStorage). Clear site data to reset.
- Payments, OTP, email and SMS are simulated (demo only).
