const fd2=(k,fields,cols)=>({k,fields,cols,edit:1,del:1});
runPortal({title:'✈ Wanderlust Travels',users:[{name:'Travel Admin',email:'admin@travel.com',password:'admin123',role:'admin'},{name:'Demo Traveller',email:'user@travel.com',password:'1234',role:'user'}],
 regRoles:['user'],hint:'Demo: admin@travel.com / admin123 · user@travel.com / 1234',
 seed:{tourism:[{place:'Kodaikanal',desc:'Misty hills, lake and pine forests.',img:'🏔'},{place:'Rameswaram',desc:'Pamban bridge and the Ramanathaswamy temple.',img:'🌉'}],
  food:[{name:'Dindigul Biryani',place:'Dindigul',price:220,desc:'Seeraga samba rice biryani.'},{name:'Jigarthanda',place:'Madurai',price:60,desc:'Famous cold drink.'}],
  hotels:[{name:'Hill View Resort',place:'Kodaikanal',price:3200,rooms:10},{name:'Sea Breeze Inn',place:'Rameswaram',price:2100,rooms:6}],
  routes:[{from:'Madurai',to:'Kodaikanal',mode:'Bus',time:'3 h',fare:150},{from:'Madurai',to:'Rameswaram',mode:'Train',time:'3.5 h',fare:90}],bookings:[]},
 tabs:{user:[
  {t:'Tourism',k:'tourism',cols:[['','img'],['Place','place'],['About','desc']],filters:[{n:'place',l:'Search place'}]},
  {t:'Food Details',k:'food',cols:[['Dish','name'],['Place','place'],RS('Price','price'),['Description','desc']],filters:[{n:'place',l:'Place'}]},
  {t:'Hotel Details',k:'hotels',cols:[['Hotel','name'],['Place','place'],RS('Per night','price'),['Rooms','rooms']],filters:[{n:'place',l:'Place'}],
   act:{l:'Book',k:'bookings',def:{status:'Booked'},ask:[{n:'checkin',l:'Check-in date (YYYY-MM-DD)',def:()=>addDays(today(),7)},{n:'nights',l:'Nights',def:2}],mk:(r,a)=>({hotel:r.name,place:r.place,checkin:a.checkin,nights:+a.nights,total:r.price*a.nights}),ok:'Accommodation booked'}},
  {t:'Route Details',k:'routes',cols:[['From','from'],['To','to'],['Mode','mode'],['Time','time'],RS('Fare','fare')],filters:[{n:'to',l:'Destination'}]},
  {t:'My Bookings',k:'bookings',own:1,cols:[['Hotel','hotel'],['Place','place'],['Check-in','checkin'],['Nights','nights'],RS('Total','total'),['Status','status']],acts:[{l:'Cancel',patch:{status:'Cancelled'},show:r=>r.status==='Booked'}]}],
 admin:[
  {t:'Post Tourism',...fd2('tourism',[{n:'place',l:'Place'},{n:'desc',l:'Description'},{n:'img',l:'Icon (emoji)',r:false}],[['','img'],['Place','place'],['About','desc']])},
  {t:'Manage Food',...fd2('food',[{n:'name',l:'Dish'},{n:'place',l:'Place'},{n:'price',l:'Price',t:'number'},{n:'desc',l:'Description'}],[['Dish','name'],['Place','place'],RS('Price','price')])},
  {t:'Manage Hotels',...fd2('hotels',[{n:'name',l:'Hotel'},{n:'place',l:'Place'},{n:'price',l:'Price per night',t:'number'},{n:'rooms',l:'Rooms',t:'number'}],[['Hotel','name'],['Place','place'],RS('Per night','price'),['Rooms','rooms']])},
  {t:'Manage Routes',...fd2('routes',[{n:'from',l:'From'},{n:'to',l:'To'},{n:'mode',l:'Mode',t:'select',o:['Bus','Train','Flight','Cab']},{n:'time',l:'Travel time'},{n:'fare',l:'Fare',t:'number'}],[['From','from'],['To','to'],['Mode','mode'],RS('Fare','fare')])},
  {t:'View Bookings',k:'bookings',cols:[W('Traveller'),['Hotel','hotel'],['Check-in','checkin'],['Nights','nights'],RS('Total','total'),['Status','status']]}]}});
