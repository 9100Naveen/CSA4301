# 30. IJSSE Journal Website

Features: author, reviewer and editor modules, manuscript submission and review, articles and journal information pages.

## Run
Open `index.html` in a browser. No server or install needed.

## Demo logins
author@ijsse.org / 1234 | reviewer@ijsse.org / 1234 | editor@ijsse.org / 1234

## Notes
- Front-end only: data is saved in the browser (localStorage). Clear site data to reset.
- Payments, OTP, email and SMS are simulated (demo only).
