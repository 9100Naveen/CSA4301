# 11. Home Finder (Real Estate)

Property search with filters, save and reuse search criteria, Google Maps, agent/company search, ads, mortgage calculator, viewing requests, customer records.

## Run
Open `index.html` in a browser. No server or install needed.

## Demo logins
Agent: agent@home.com / admin123 | Buyer: buyer@home.com / 1234

## Notes
- Front-end only: data is saved in the browser (localStorage). Clear site data to reset.
- Passwords are plain text; payments, OTP, email and SMS are simulated (demo only).
