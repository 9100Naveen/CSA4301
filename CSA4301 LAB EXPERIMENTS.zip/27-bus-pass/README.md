# 27. Bus Pass System

Features: student and route bus passes, an eWallet, eTickets, QR codes and conductor verification.

## Run
Open `index.html` in a browser. No server or install needed.

## Demo logins
user@pass.com / 1234 | conductor@pass.com / 1234 | admin@pass.com / admin123

## Notes
- Front-end only: data is saved in the browser (localStorage). Clear site data to reset.
- Payments, OTP, email and SMS are simulated (demo only).
- QR images load from a CDN, so they need internet; the code text is shown otherwise.
