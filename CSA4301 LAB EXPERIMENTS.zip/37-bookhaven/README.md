# 37. BookHaven Online Bookstore

Features: a book catalogue, cart and checkout, and the About, Contact, FAQ, Privacy and Blog pages.

## Run
Open `index.html` in a browser. No server or install needed.

## Demo logins
reader@book.com / 1234 | admin@book.com / admin123

## Notes
- Front-end only: data is saved in the browser (localStorage). Clear site data to reset.
- Payments, OTP, email and SMS are simulated (demo only).
