# 47. Online Phone Bill Payment

Features: monthly bills, a fine for late payment, full or partial payment, billing history and auto-pay settings.

## Run
Open `index.html` in a browser. No server or install needed.

## Demo logins
cust@phone.com / 1234 | admin@phone.com / admin123

## Notes
- Front-end only: data is saved in the browser (localStorage). Clear site data to reset.
- Payments, OTP, email and SMS are simulated (demo only).
