# 33. KodaikanalEats

Features: suite booking with seasonal pricing, room availability, room boys, restaurants and table reservation.

## Run
Open `index.html` in a browser. No server or install needed.

## Demo logins
guest@eats.com / 1234 | admin@eats.com / admin123

## Notes
- Front-end only: data is saved in the browser (localStorage). Clear site data to reset.
- Payments, OTP, email and SMS are simulated (demo only).
