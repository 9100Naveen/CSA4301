# 44. Online Placement Examination

Features: exam scheduling, a timed test, automatic evaluation, ranked results and a scorecard.

## Run
Open `index.html` in a browser. No server or install needed.

## Demo logins
cand@exam.com / 1234 | admin@exam.com / admin123

## Notes
- Front-end only: data is saved in the browser (localStorage). Clear site data to reset.
- Payments, OTP, email and SMS are simulated (demo only).
