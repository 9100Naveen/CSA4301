# 34. LearnWell Tuition Centre

Features: announcements, course offerings, enrolment, fee reports, feedback and maintenance requests.

## Run
Open `index.html` in a browser. No server or install needed.

## Demo logins
student@learn.com / 1234 | teacher@learn.com / 1234 | admin@learn.com / admin123

## Notes
- Front-end only: data is saved in the browser (localStorage). Clear site data to reset.
- Payments, OTP, email and SMS are simulated (demo only).
