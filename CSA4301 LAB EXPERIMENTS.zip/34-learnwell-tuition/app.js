const SUBJ=()=>CL('subjects').map(s=>s.name),ann=[['Date','date'],['Title','title'],['Notice','body']];
const sumBy=(rows,len)=>Object.entries(rows.reduce((a,r)=>{const k=r.date.slice(0,len);a[k]=(a[k]||0)+ +r.amount;return a},{})).sort().reverse().map(([k,v])=>[k,rs(v)]);
runPortal({title:'🎓 LearnWell Tuition Centre',users:[{name:'Centre Admin',email:'admin@learn.com',password:'admin123',role:'admin'},{name:'Mrs. Priya',email:'teacher@learn.com',password:'1234',role:'teacher'},{name:'Demo Student',email:'student@learn.com',password:'1234',role:'student'}],
 regRoles:['student','teacher'],hint:'Demo: admin@learn.com / admin123 · teacher@learn.com / 1234 · student@learn.com / 1234',
 seed:{subjects:[{name:'Mathematics (Class 10)',duration:'6 months',fee:6000,mode:'Both',teacher:'Mrs. Priya'},{name:'Physics (Class 12)',duration:'8 months',fee:8000,mode:'Offline',teacher:'Mrs. Priya'},{name:'Spoken English',duration:'3 months',fee:3000,mode:'Online',teacher:'Mrs. Priya'}],
  announcements:[{title:'Monthly test',body:'Class 10 maths test on Saturday 10 am.'},{title:'Holiday notice',body:'Centre closed on Friday for Deepavali.'}],enrollments:[{user:'student@learn.com',subject:'Mathematics (Class 10)',mode:'Offline'}],fees:[{user:'student@learn.com',subject:'Mathematics (Class 10)',amount:2000,method:'UPI',date:today()}],requests:[],feedback:[{user:'student@learn.com',text:'Classes are clear and well paced.'}]},
 tabs:{admin:[
  {t:'Teachers',type:'users',role:'teacher',del:1,add:[{n:'name',l:'Teacher name'},{n:'email',l:'Login email',t:'email'},{n:'password',l:'Password'}]},
  {t:'Students',type:'custom',fn:m=>{m.innerHTML=`<div class="card"><h3>Students and fees paid</h3>${tbl(['Student','Email','Fees paid','Subjects'],Auth.users().filter(u=>u.role==='student').map(u=>[esc(u.name),u.email,rs(CL('fees').filter(f=>f.user===u.email).reduce((s,f)=>s+ +f.amount,0)),esc(CL('enrollments').filter(e=>e.user===u.email).map(e=>e.subject).join(', ')||'-')]))}</div>`}},
  {t:'Subjects',k:'subjects',fields:[{n:'name',l:'Subject'},{n:'duration',l:'Duration'},{n:'fee',l:'Fee (₹)',t:'number'},{n:'mode',l:'Mode',t:'select',o:['Online','Offline','Both']},{n:'teacher',l:'Teacher',t:'select',o:()=>Auth.users().filter(u=>u.role==='teacher').map(u=>u.name)}],cols:[['Subject','name'],['Duration','duration'],RS('Fee','fee'),['Mode','mode'],['Teacher','teacher']],edit:1,del:1},
  {t:'Announcements',k:'announcements',fields:[{n:'title',l:'Title'},{n:'body',l:'Notice',t:'textarea'}],cols:ann,del:1},
  {t:'Reports',type:'custom',fn:m=>{m.innerHTML=`<div class="card"><h3>Monthly fee report</h3>${tbl(['Month','Collected'],sumBy(CL('fees'),7))}</div><div class="card"><h3>Yearly fee report</h3>${tbl(['Year','Collected'],sumBy(CL('fees'),4))}</div><div class="card"><h3>Feedback report</h3>${tbl(['Student','Feedback'],CL('feedback').map(f=>[esc(UN(f.user)),esc(f.text)]))}</div>`}},
  {t:'Maintenance Requests',k:'requests',cols:[W('From'),['Date','date'],['Request','text'],['Status','status']],status:{o:['Open','In progress','Done']}}],
 teacher:[
  {t:'Announcements',k:'announcements',fields:[{n:'title',l:'Title'},{n:'body',l:'Notice',t:'textarea'}],cols:ann,del:1},
  {t:'My Subjects',k:'subjects',where:(r,me)=>r.teacher===me.name,cols:[['Subject','name'],['Duration','duration'],['Mode','mode'],RS('Fee','fee')]},
  {t:'Enrolled Students',k:'enrollments',cols:[W('Student'),['Subject','subject'],['Mode','mode'],['Date','date']]}],
 student:[
  {t:'Announcements',k:'announcements',cols:ann},
  {t:'Course Offerings',k:'subjects',cols:[['Subject','name'],['Duration','duration'],RS('Fee','fee'),['Mode','mode'],['Teacher','teacher']],act:{l:'Enroll',k:'enrollments',ask:[{n:'mode',l:'Online or Offline?',def:'Offline'}],mk:r=>({subject:r.name}),ok:'Enrolled'}},
  {t:'My Fees',k:'fees',own:1,fields:[{n:'subject',l:'Subject',t:'select',o:SUBJ},{n:'amount',l:'Amount (₹)',t:'number'},{n:'method',l:'Mode',t:'select',o:['UPI','Card','Cash at centre']}],cols:[['Date','date'],['Subject','subject'],RS('Amount','amount'),['Mode','method']]},
  {t:'Maintenance Request',k:'requests',own:1,def:{status:'Open'},fields:[{n:'text',l:'Issue / request',t:'textarea'}],cols:[['Date','date'],['Request','text'],['Status','status']]},
  {t:'Feedback',k:'feedback',own:1,fields:[{n:'text',l:'Your feedback',t:'textarea'}],cols:[['Date','date'],['Feedback','text']]},
  {t:'Profile',type:'profile',fields:['phone','class']}]}});
