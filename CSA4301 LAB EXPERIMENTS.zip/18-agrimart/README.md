# 18. AgriMart

Farmers add products and manage orders/shipping; public users search, wallet, cart, shipping address, orders. OTP verification.

## Run
Open `index.html` in a browser. No server or install needed.

## Demo logins
Farmer: farmer@agri.com / 1234 | Public: public@agri.com / 1234 (OTP shown on screen)

## Notes
- Front-end only: data is saved in the browser (localStorage). Clear site data to reset.
- Passwords are plain text; payments, OTP, email and SMS are simulated (demo only).
