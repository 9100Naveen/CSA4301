# 16. ComplainEase

Post complaints with Google Map location and proof, track status, feedback; officers update status and proof of work; admin generates officer logins, assigns, manages accounts and hides features.

## Run
Open `index.html` in a browser. No server or install needed.

## Demo logins
Admin: admin@comp.com / admin123 | Officer: officer@comp.com / 1234 | Citizen: user@comp.com / 1234

## Notes
- Front-end only: data is saved in the browser (localStorage). Clear site data to reset.
- Passwords are plain text; payments, OTP, email and SMS are simulated (demo only).
