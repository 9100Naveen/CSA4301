# 15. EasyToll

eWallet, buy toll eTicket, apply/renew toll pass, QR codes, admin approval, toll gate QR verification. QR images need internet (cdnjs); the code text is shown otherwise.

## Run
Open `index.html` in a browser. No server or install needed.

## Demo logins
Admin: admin@toll.com / admin123 | Driver: user@toll.com / 1234 | Toll gate: gate@toll.com / 1234

## Notes
- Front-end only: data is saved in the browser (localStorage). Clear site data to reset.
- Passwords are plain text; payments, OTP, email and SMS are simulated (demo only).
