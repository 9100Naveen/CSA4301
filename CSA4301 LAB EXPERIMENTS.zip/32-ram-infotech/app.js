const LC=[['Model','model'],['Brand','brand'],['Configuration','config'],RS('Price','price'),['In stock','stock']];
const store={k:'laptops',filters:[{n:'brand',l:'Brand'},{l:'Max price',fn:(r,v)=>r.price<=+v}],cols:LC,act:{l:'Buy',k:'sales',def:{status:'Ordered'},check:r=>r.stock<1?'Out of stock':'',mk:r=>({model:r.model,amount:r.price}),ok:'Order placed'}};
runPortal({title:'💻 Ram Infotech',users:[{name:'Ram Admin',email:'admin@ram.com',password:'admin123',role:'admin'},{name:'Demo Customer',email:'cust@ram.com',password:'1234',role:'customer'}],
 regRoles:['customer','admin'],hint:'Demo: admin@ram.com / admin123 · cust@ram.com / 1234',
 seed:{laptops:[{model:'ProBook 14',brand:'HP',config:'i5 / 16 GB / 512 GB SSD',price:58000,stock:6},{model:'Inspiron 15',brand:'Dell',config:'Ryzen 5 / 8 GB / 512 GB',price:46000,stock:4},{model:'ThinkPad E14',brand:'Lenovo',config:'i7 / 16 GB / 1 TB',price:72000,stock:2}],sales:[{user:'cust@ram.com',model:'ProBook 14',amount:58000,status:'Delivered'}],
  services:[{user:'cust@ram.com',model:'Inspiron 15',issue:'Battery not charging',status:'In repair'}],rentals:[{customer:'Corporate Client Ltd',model:'ProBook 14',rent:2500,start:'2026-01-01',months:12,deposit:10000}],contact:[]},
 pub:{Home:{type:'html',html:'<h2>Buy and service laptops</h2><p>Genuine laptops with warranty, plus a service centre for repairs and upgrades.</p>'},
  'Online Store':{...store,cols:LC.slice(0,5)},
  'Service Center':{type:'html',html:'<h3>Service centre</h3><p>Login to book a repair, track status and read troubleshooting guides. Typical turnaround: 2–4 working days.</p>'},
  'About Us':{type:'html',html:'<h3>About us</h3><p>Ram Infotech has sold and serviced laptops since 2010.</p>'},
  FAQ:{type:'html',html:'<h3>FAQ</h3><p><b>Warranty?</b> 1 year on all new laptops.<br><b>Pick-up service?</b> Yes, within the city.<br><b>Rental?</b> Monthly plans for businesses.</p>'},
  Contact:{k:'contact',noTable:1,form:'Contact us',btn:'Send',ok:'Message sent',fields:[{n:'name',l:'Name'},{n:'phone',l:'Phone'},{n:'msg',l:'Message',t:'textarea'}],cols:[]}},
 tabs:{admin:[
  {t:'Laptop Sales Details',k:'laptops',fields:[{n:'model',l:'Model'},{n:'brand',l:'Brand'},{n:'config',l:'Configuration'},{n:'price',l:'Price',t:'number'},{n:'stock',l:'Stock',t:'number'}],cols:LC,edit:1,del:1},
  {t:'Services',k:'services',cols:[W('Customer'),['Laptop','model'],['Issue','issue'],['Status','status']],status:{o:['Received','In repair','Ready','Delivered']}},
  {t:'Customers',type:'custom',fn:m=>{m.innerHTML=`<div class="card"><h3>Customer purchases</h3>${tbl(['Customer','Laptop','Amount','Status'],CL('sales').map(s=>[esc(UN(s.user)),esc(s.model),rs(s.amount),s.status]))}</div><div class="card"><h3>Customer services</h3>${tbl(['Customer','Laptop','Issue','Status'],CL('services').map(s=>[esc(UN(s.user)),esc(s.model),esc(s.issue),s.status]))}</div>`}},
  {t:'Rental Agreements',k:'rentals',fields:[{n:'customer',l:'Customer / company'},{n:'model',l:'Laptop model'},{n:'rent',l:'Rent per month',t:'number'},{n:'start',l:'Start date',t:'date'},{n:'months',l:'Period (months)',t:'number'},{n:'deposit',l:'Deposit',t:'number'}],cols:[['Customer','customer'],['Laptop','model'],RS('Rent/month','rent'),['Start','start'],['Months','months'],RS('Deposit','deposit')],del:1},
  {t:'Stock Maintenance',k:'laptops',cols:[['Model','model'],['Brand','brand'],['Stock','stock']],acts:[{l:'Update stock',ask:[{n:'stock',l:'New stock quantity'}]}]}],
 customer:[{t:'Online Store',...store},{t:'My Purchases',k:'sales',own:1,cols:[['Date','date'],['Laptop','model'],RS('Amount','amount'),['Status','status']]},
  {t:'Book Service',k:'services',own:1,def:{status:'Received'},fields:[{n:'model',l:'Laptop model'},{n:'issue',l:'Problem',t:'textarea'}],cols:[['Date','date'],['Laptop','model'],['Issue','issue'],['Status','status']]},
  {t:'Troubleshooting',type:'html',html:'<h3>Troubleshooting guide</h3><ul><li>Laptop not starting: hold the power button for 15 seconds, then try the charger.</li><li>Slow performance: close startup apps and check disk space.</li><li>Wi-Fi drops: update the network driver and restart the router.</li></ul>'}]}});
