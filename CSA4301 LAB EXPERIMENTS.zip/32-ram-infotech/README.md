# 32. Ram Infotech (Laptop Sales and Service)

Features: laptop sales, service booking and tracking, rental agreements and stock maintenance.

## Run
Open `index.html` in a browser. No server or install needed.

## Demo logins
cust@ram.com / 1234 | admin@ram.com / admin123

## Notes
- Front-end only: data is saved in the browser (localStorage). Clear site data to reset.
- Payments, OTP, email and SMS are simulated (demo only).
